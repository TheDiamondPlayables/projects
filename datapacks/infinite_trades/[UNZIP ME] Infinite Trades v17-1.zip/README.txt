Hey there, and thank you for using my project!

If you have any questions, check out my Discord, 
and leave your questions there:
cutt.ly/tdpDiscord

If you really like the project and want me to make some more,
consider supporting my work on Patreon: patreon.com/thediamondplayables.

Your Patron Support helps keeps me going and working on more and better projects!

Also, you can share my work in any way you want, 
but you must give them the PlanetMinecraft link of the project's post.
(and make sure they see it - that goes without saying)

Reuploading is not allowed under any circumstances.

TheDiamondPlayables is one person, not a squad/organization.
There's just me working on all of this.